# JavaFX-Game
 A basic JavaFX game
